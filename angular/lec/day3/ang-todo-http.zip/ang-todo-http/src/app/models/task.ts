export class Task{
    ID:number=0;
    Title:string="";
    IsDone:boolean=false;
}
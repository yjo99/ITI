export class LoginViewModel
{
    Email:string;
    Password:string;
    IP:string;

}
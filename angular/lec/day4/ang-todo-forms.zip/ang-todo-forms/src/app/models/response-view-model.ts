export class ResponseViewModel{
    Data:any;
    Message:string="";
    Success:boolean=false;
}
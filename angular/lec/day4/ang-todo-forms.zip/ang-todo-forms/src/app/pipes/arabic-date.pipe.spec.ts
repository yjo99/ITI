import { ArabicDatePipe } from './arabic-date.pipe';

describe('ArabicDatePipe', () => {
  it('create an instance', () => {
    const pipe = new ArabicDatePipe();
    expect(pipe).toBeTruthy();
  });
});


export class Student{
    firstName:string="Mohamed";
    lastName:string="Ali";
    age:number=36;
    imageURL="https://www.daralnahda.com/images/logo.png";
}
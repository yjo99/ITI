export class Mobile2Service
{
   
    constructor(){
        alert("MobileService");
    }
    isValidMobileNumber(mobile:string):boolean
{
  return true;
}
}
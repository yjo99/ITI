


public interface WorldDao extends CountryDao,CityDao {

}
